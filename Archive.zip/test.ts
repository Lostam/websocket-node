// let ioClient = require('socket.io-client');
//
// let socketEmitter = ioClient.connect('http://localhost:80');
// setInterval(() => {
//     let ran = (Math.random() * 100).toString(36).substring(2, 8) + "::" + '111111';
//     socketEmitter.emit('dataSync', {data: ran})
// }, 500);
import {Logger} from "./Logger";
