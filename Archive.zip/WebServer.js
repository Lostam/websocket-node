"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Logger_1 = require("./Logger");
var app = require('express')();
var http = require('http').createServer(app);
var ioClient = require('socket.io-client');
var ioServer = require('socket.io').listen(http);
var WebServer = (function () {
    function WebServer() {
        this.port = 80;
        this.data = [];
        this.id = WebServer.generateSixDigitId();
        http.listen(this.port);
        console.log('Listening...');
        this.setUpConnection();
    }
    WebServer.prototype.setUpConnection = function () {
        var _this = this;
        ioServer.sockets.on('connection', function (socket) {
            console.log('connected');
            socket.on('dataSync', function (data) {
                console.log(data);
                _this.data.push(data);
            });
        });
    };
    WebServer.prototype.printData = function () {
        console.log(this.data);
        Logger_1.Logger.log({ data: this.data, id: this.id });
        this.data = [];
    };
    WebServer.generateSixDigitId = function () {
        var arr = [];
        for (var i = 0; i < 6; i++) {
            arr[i] = Math.ceil(Math.random() * 6);
        }
        return arr.join('');
    };
    WebServer.prototype.getId = function () {
        return this.id;
    };
    WebServer.prototype.getPort = function () {
        return this.port;
    };
    return WebServer;
}());
var web = new WebServer();
setInterval(function () {
    web.printData();
}, 1000 * 60 * 3);
var socketEmitter = ioClient.connect(process.env.NODE_URL);
setInterval(function () {
    var ran = (Math.random() * 100).toString(36).substring(2, 8) + "::" + web.getId();
    socketEmitter.emit('dataSync', { data: ran });
}, 500);
//# sourceMappingURL=WebServer.js.map