"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var internode_1 = require("./internode");
/**
 * Created by oded on 6/5/17.
 */
//for serialization
var DataStore = (function () {
    function DataStore(nodeID) {
        this.items = {};
        this.node_id = nodeID;
        this.nodeSyncIndex = new Map();
    }
    DataStore.prototype.itemCount = function () {
        return Object.keys(this.items).length;
    };
    DataStore.prototype.set = function (key, value, expire) {
        var item = new Item();
        item.value = value;
        item.time = Date.now();
        if (!item.synced_nodes) {
            item.synced_nodes = [];
        }
        else {
            item.synced_nodes.length = 0;
        }
        item.synced_nodes.push(this.node_id);
        if (expire) {
            item.expire = Date.now() + expire;
        }
        this.items[key] = item;
    };
    DataStore.prototype.get = function (key) {
        var item = this.items[key];
        if (!item)
            return null;
        return item.value;
    };
    DataStore.prototype.aggregate = function (key, value, expire) {
        var aggregateKey = this.aggregateKey(key);
        var oldItem = this.items[aggregateKey];
        var newValue;
        if (oldItem) {
            newValue = parseFloat(oldItem.value) + value;
        }
        else {
            newValue = value;
        }
        this.set(aggregateKey, newValue, expire);
    };
    DataStore.prototype.aggregateKey = function (key) {
        return this.aggregateKeyPrefix(key) + this.node_id;
    };
    DataStore.prototype.aggregateKeyPrefix = function (key) {
        return key + '::';
    };
    DataStore.prototype.getAggregated = function (key) {
        var aggregatedItemValue = 0;
        var shardsMessage = '';
        for (var itemKey in this.items) {
            if (!this.items.hasOwnProperty(itemKey))
                continue;
            if (itemKey.startsWith(key)) {
                var item = this.items[itemKey];
                if (item.value) {
                    shardsMessage += '\n- ' + itemKey + ' - ' + item.value;
                    aggregatedItemValue += parseFloat(item.value);
                }
            }
        }
        if (aggregatedItemValue) {
            var logMessage = 'aggregatedItemValue\nrequestedKey:' + key + ' - agg value - ' + aggregatedItemValue + shardsMessage;
            internode_1.InterNode.log(logMessage);
        }
        return aggregatedItemValue;
    };
    DataStore.prototype.getDataStoreDiff = function (nodeId) {
        var diffItems = {};
        var diffItemCount = 0;
        var itemIndex = 0;
        //reset the index if we're done with all of the items
        if (this.nodeSyncIndex.get(nodeId) >= this.itemCount()) {
            this.nodeSyncIndex.set(nodeId, 0);
        }
        for (var key in this.items) {
            if (!this.items.hasOwnProperty(key))
                continue;
            if (this.nodeSyncIndex.get(nodeId) && itemIndex < this.nodeSyncIndex.get(nodeId)) {
                //if this index location was already synced to that domain, skip it
                itemIndex++;
                continue;
            }
            else {
                this.nodeSyncIndex.set(nodeId, itemIndex);
                itemIndex++;
            }
            var item = this.items[key];
            //delete item if expired
            if (!item.expire || item.expire < Date.now()) {
                delete this.items[key];
                continue;
            }
            if (item.synced_nodes.indexOf(nodeId) == -1) {
                diffItems[key] = item;
                item.synced_nodes.push(nodeId);
                diffItemCount++;
            }
            if (diffItemCount >= DataStore.ITEMS_TO_SYNC_EACH_TIME) {
                break;
            }
        }
        var dataStoreDiff = new DataStore(this.node_id);
        dataStoreDiff.items = diffItems;
        var logMessage = 'DataStore diff has ' + Object.keys(dataStoreDiff.items).length + ' items for ' + nodeId;
        internode_1.InterNode.log(logMessage);
        return dataStoreDiff;
    };
    DataStore.prototype.receiveSync = function (parsedSyncData) {
        var remoteItems = parsedSyncData.items;
        var itemCount = Object.keys(remoteItems).length;
        if (itemCount) {
            internode_1.InterNode.log('Receiving ' + itemCount + ' items');
        }
        else {
            internode_1.InterNode.log('No items Received');
        }
        for (var remoteItemKey in remoteItems) {
            if (!remoteItems.hasOwnProperty(remoteItemKey))
                continue;
            var remoteItem = remoteItems[remoteItemKey];
            //get rid of corrupted items that don't have data in them
            if (!remoteItem.value)
                continue;
            var localItem = this.items[remoteItemKey];
            // let itemLog = 'from ' + parsedSyncData.node_id + ' : ' + remoteItemKey + ' NewItem: ' + JSON.stringify(remoteItem) + ' OldItem: ' + JSON.stringify(localItem);
            if (!localItem) {
                localItem = new Item();
                // InterNode.log('Adding item ' + itemLog);
            }
            if (!localItem.time || remoteItem.time > localItem.time) {
                // InterNode.log('Updating item ' + itemLog);
                localItem.time = remoteItem.time;
                localItem.value = remoteItem.value;
                localItem.expire = remoteItem.expire;
            }
            /*else {
             InterNode.log('Just Noting item synced nodes ' + itemLog);
             }*/
            var nodeSet = new Set(remoteItem.synced_nodes);
            nodeSet.add(internode_1.InterNode.nodeID);
            localItem.synced_nodes = Array.from(nodeSet);
            this.items[remoteItemKey] = localItem;
        }
    };
    return DataStore;
}());
DataStore.ITEMS_TO_SYNC_EACH_TIME = 100;
exports.DataStore = DataStore;
//for serialization
var Item = (function () {
    function Item() {
    }
    return Item;
}());
exports.Item = Item;
//# sourceMappingURL=datastore.js.map