"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var synchronizer_1 = require("./synchronizer");
var datastore_1 = require("./datastore");
/**
 * Created by oded on 5/3/17.
 */
var InterNode = (function () {
    function InterNode() {
    }
    InterNode.getNodeID = function () {
        return InterNode.nodeID;
    };
    InterNode.init = function (ioServer, ioClient) {
        var hosts = [];
        for (var _i = 2; _i < arguments.length; _i++) {
            hosts[_i - 2] = arguments[_i];
        }
        InterNode.nodeID = Math.random().toString(36).substring(2, 8);
        InterNode.dataStore = new datastore_1.DataStore(InterNode.nodeID);
        InterNode.log('node ' + InterNode.nodeID + ' is up');
        var syncPath = 'sync', newDataPath = 'newData';
        InterNode.synchronizer = new synchronizer_1.Synchronizer(InterNode.SYNC_INTERVAL, hosts, syncPath, InterNode.nodeID, InterNode.dataStore);
        ioServer.on(syncPath, InterNode.sync());
        ioServer.on(newDataPath, InterNode.receiveBroadcast());
        // ioServer(syncPath, InterNode.receiveHttpGet());
    };
    InterNode.itemCount = function () {
        return InterNode.dataStore.itemCount();
    };
    InterNode.set = function (key, value, expire) {
        InterNode.dataStore.set(key, value, expire);
    };
    InterNode.get = function (key) {
        return InterNode.dataStore.get(key);
    };
    InterNode.aggregate = function (key, value, expire) {
        InterNode.dataStore.aggregate(key, value, expire);
    };
    InterNode.getAggregated = function (key) {
        return InterNode.dataStore.getAggregated(key);
    };
    InterNode.broadCast = function () {
    };
    InterNode.sync = function () {
        return function (req, res) {
            if (InterNode.synchronizer.isFreshData(req)) {
                res.send(InterNode.dataStore.getDataStoreDiff(req.query.node_id));
            }
            else {
                res.send({ status: Status.NOTHING_NEW });
            }
        };
    };
    InterNode.receiveBroadcast = function () {
        return function (data) {
            if (InterNode.synchronizer.isFreshData(data)) {
                // res.send(InterNode.dataStore.getDataStoreDiff(data.query.node_id));
            }
            else {
                // res.send({status: Status.NOTHING_NEW});
            }
        };
    };
    InterNode.log = function (message) {
        if (InterNode.logHandler) {
            InterNode.logHandler('internode: ' + InterNode.nodeID + ' : ' + message);
        }
    };
    InterNode.setLogHandler = function (logHandler) {
        InterNode.logHandler = logHandler;
    };
    return InterNode;
}());
InterNode.SYNC_INTERVAL = 10 * 1000; //10s
exports.InterNode = InterNode;
var Status = (function () {
    function Status() {
    }
    return Status;
}());
Status.NOTHING_NEW = 'nothing_new';
exports.Status = Status;
//# sourceMappingURL=internode.js.map