"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var internode_1 = require("./internode");
/**
 * Created by oded on 6/5/17.
 */
var Synchronizer = (function () {
    function Synchronizer(syncInterval, hosts, syncPath, nodeID, dataStore) {
        var _this = this;
        this.hosts = hosts;
        this.syncPath = syncPath;
        this.nodeID = nodeID;
        this.dataStore = dataStore;
        setInterval(function () {
            _this.sync();
        }, syncInterval);
    }
    Synchronizer.prototype.sync = function () {
        var _this = this;
        var randomHost = this.hosts[Math.floor(Math.random() * this.hosts.length)];
        var url = randomHost + this.syncPath + '?node_id=' + this.nodeID;
        internode_1.InterNode.log('syncing from ' + url);
        require('request').get({
            url: url,
        }, function (error, response, body) {
            if (body && response && response.statusCode == 200) {
                try {
                    var parsedSyncData = JSON.parse(body);
                    if (parsedSyncData.status) {
                        internode_1.InterNode.log('received status: ' + parsedSyncData.status);
                    }
                    else {
                        _this.dataStore.receiveSync(parsedSyncData);
                    }
                }
                catch (error) {
                    internode_1.InterNode.log('receiveSync error: ' + JSON.stringify(error));
                    return;
                }
            }
            else {
                internode_1.InterNode.log(error + ' | ' + randomHost + ' | ' + JSON.stringify(response) + ' | ' + body);
            }
        });
    };
    //does this node have fresh data for the requesting node?
    Synchronizer.prototype.isFreshData = function (req) {
        if (req.query.node_id === internode_1.InterNode.nodeID) {
            internode_1.InterNode.log('do not sync: same server');
            return false;
        }
        else if (Object.keys(this.dataStore.items).length < 1) {
            internode_1.InterNode.log('do not sync: no data');
            return false;
        }
        return true;
    };
    return Synchronizer;
}());
exports.Synchronizer = Synchronizer;
//# sourceMappingURL=synchronizer.js.map