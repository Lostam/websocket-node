import {Logger} from "./Logger";

const app = require('express')();
const http = require('http').createServer(app);
let ioClient = require('socket.io-client');
let ioServer = require('socket.io').listen(http);

class WebServer {
    private id: string;
    private port = 80;
    private data: any[] = [];

    constructor() {
        this.id = WebServer.generateSixDigitId();
        http.listen(this.port);
        console.log('Listening...');
        this.setUpConnection()
    }

    setUpConnection() {

        ioServer.sockets.on('connection', (socket) => {
            console.log('connected');

            socket.on('dataSync', (data) => {
                console.log(data);
                this.data.push(data);
            });
        });
    }

    printData() {
        console.log(this.data);
        Logger.log({data: this.data, id: this.id});
        this.data = [];
    }

    static generateSixDigitId() {
        let arr = [];
        for (let i = 0; i < 6; i++) {
            arr[i] = Math.ceil(Math.random() * 6)
        }
        return arr.join('');
    }

    public getId() {
        return this.id;
    }

    public getPort() {
        return this.port;
    }
}

let web = new WebServer();

setInterval(() => {
    web.printData();
}, 1000 * 60 * 3);


let socketEmitter = ioClient.connect(process.env.NODE_URL);
setInterval(() => {
    let ran = (Math.random() * 100).toString(36).substring(2, 8) + "::" + web.getId();
    socketEmitter.emit('dataSync', {data: ran})
}, 500);